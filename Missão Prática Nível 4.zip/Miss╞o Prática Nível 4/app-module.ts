@NgModule({
    declarations: [
    ],
    imports: [
      FormsModule, 
    ],
    bootstrap: [AppComponent]
  })
  export class AppModule { }
