
import React from 'react';
import { useNavigate } from 'react-router-dom';

const LivroDados = () => {
  return (
    <main>
      <h1>Olá mundo</h1>
    </main>
  );
};

const opcoes = controleEditora.getEditoras().map(editora => ({
    value: editora.codEditora,
    text: editora.nome
  }));

const [titulo, setTitulo] = useState('');
const [resumo, setResumo] = useState('');
const [autores, setAutores] = useState('');
const [codEditora, setCodEditora] = useState(opcoes.length > 0 ? opcoes[0].value : 0);

const navigate = useNavigate();

const tratarCombo = (evento) => {
    setCodEditora(Number(evento.target.value));
  };

  const incluir = (evento) => {
    evento.preventDefault();
  
    const livro = {
      codigo: 0,
      titulo: titulo,
      resumo: resumo,
      autores: autores.split('\n'),
      codEditora: codEditora
    };
  
    controleLivro.incluir(livro);
    navigate('/');
  };

  return (
    <main>
      <h1>Incluir Livro</h1>
      <form onSubmit={incluir}>
        <div>
          <label>Título:</label>
          <input type="text" value={titulo} onChange={(e) => setTitulo(e.target.value)} />
        </div>
        <div>
          <label>Resumo:</label>
          <textarea value={resumo} onChange={(e) => setResumo(e.target.value)} />
        </div>
        <div>
          <label>Autores:</label>
          <textarea value={autores} onChange={(e) => setAutores(e.target.value)} />
        </div>
        <div>
          <label>Editora:</label>
          <select value={codEditora} onChange={tratarCombo}>
            {opcoes.map(opcao => (
              <option key={opcao.value} value={opcao.value}>{opcao.text}</option>
            ))}
          </select>
        </div>
        <button type="submit">Incluir</button>
      </form>
    </main>
  );

export default LivroDados;