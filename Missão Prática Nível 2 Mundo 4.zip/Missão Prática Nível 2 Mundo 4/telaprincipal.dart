class TelaPrincipal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BarraNavegacao(),
      body: Column(
        children: [
          BannerDestaque(),
          SizedBox(height: 20),
          PesquisaRapida(),
          // Outros componentes, como listas de destinos ou pacotes de viagem
        ],
      ),
    );
  }
}

void main() => runApp(MaterialApp(
  home: TelaPrincipal(),
));
