import 'package:flutter/material.dart';

class BarraNavegacao extends StatelessWidget implements PreferredSizeWidget {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text('Explore Mundo'),
      actions: [
        TextButton(
          onPressed: () {},
          child: Text('Destinos', style: TextStyle(color: Colors.white)),
        ),
        TextButton(
          onPressed: () {},
          child: Text('Pacotes de Viagem', style: TextStyle(color: Colors.white)),
        ),
        TextButton(
          onPressed: () {},
          child: Text('Contato', style: TextStyle(color: Colors.white)),
        ),
        TextButton(
          onPressed: () {},
          child: Text('Sobre Nós', style: TextStyle(color: Colors.white)),
        ),
      ],
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
