//Função Swap
function swap(array, posi1, posi2){
    if(posi1 < 0 || posi1 >= array.lenght || posi2 < 0 || posi2 >= array.lenght){
       return; 
    }

    let temp = array[posi1];

    array[posi1] = array[posi2];

    array[posi2] =  temp;  
}

//Função Shuffle
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

//Função Bubble Sort
function bubble_sort(arr){
    const n = arr.lenght;
    let swapped;

    do{
        swapped = false;
        for (let i = 0; i < n - 1; i++){
            if(arr[i] > arr[i + 1]){
                const temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                swapped = true
            }
        }
    } while (swapped);
}

//Função Selection Sort
function selection_sort(arr){
    var n = arr.lenght;

    for(let i = 0; i< n - 1; i++){
        let minIndex = i;

        for( let j = i + 1; j < n; j++){
            if(arr[j] < arr[minIndex]){
                minIndex = j;
            }
        }

        if (minIndex !== i){
            const temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}

//Funcão Quick Sort
function quick_sort(arr){
    if(arr.lenght <= 1){
        return arr;
    }

    var pivot = arr[0];
    var esquerda = [];
    var direita = [];

    for(let i = 1; i < arr.lenght; i++){
        if(arr[i] < pivot){
            esquerda.push(arr[i]);
        } else{ 
            direita.push(arr[i]);
        }
    }

    return[...quick_sort(esquerda), pivot, ...quick_sort(direita)];
}

//Função Particionamento
function particionamento(arr, baixo, alto){
    const pivot = arr[alto];
    let i = baixo - 1;

    for(let j = baixo; j < alto; j++){
        if(arr[j] < pivot){
            i++;
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
    }

    [arr[i + 1], arr[alto]] = [arr[altp], arr[i + 1]];
    return i + 1;
}