
class Livro {
    codigo: number;
    codEditora: number;
    titulo: string;
    resumo: string;
    autores: string[];
  
    constructor(codigo: number, codEditora: number, titulo: string, resumo: string, autores: string[]) {
      this.codigo = codigo;
      this.codEditora = codEditora;
      this.titulo = titulo;
      this.resumo = resumo;
      this.autores = autores;
    }
  }

const livros: Livro[] = [
  { codigo: 1, codEditora: 1, titulo: 'Livro 1', resumo: 'Resumo do livro 1', autores: ['Autor 1'] },
  { codigo: 2, codEditora: 2, titulo: 'Livro 2', resumo: 'Resumo do livro 2', autores: ['Autor 2'] },
  { codigo: 3, codEditora: 3, titulo: 'Livro 3', resumo: 'Resumo do livro 3', autores: ['Autor 3'] }
];

class ControleLivro {
  obterLivros(): Livro[] {
    return livros;
  }


  incluir(livro: Livro): void {
    const codigoMaisAlto = Math.max(...livros.map(l => l.codigo));
    livro.codigo = codigoMaisAlto + 1;
    livros.push(livro);
  }

 
  excluir(codigo: number): void {
    const indice = livros.findIndex(l => l.codigo === codigo);
    if (indice !== -1) {
      livros.splice(indice, 1);
    }
  }
}

export default ControleLivro;