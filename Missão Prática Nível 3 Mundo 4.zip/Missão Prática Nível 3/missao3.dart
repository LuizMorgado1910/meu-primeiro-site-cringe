name: wearable_assist_app
description: A Wear OS app to assist employees with special needs using TTS.
version: 1.0.0+1

environment:
  sdk: ">=2.17.0 <3.0.0"

dependencies:
  flutter:
    sdk: flutter
  flutter_tts: ^3.3.0

flutter:
  uses-material-design: true


import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() => runApp(WearOSAssistApp());

class WearOSAssistApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AssistHomePage(),
    );
  }
}

class AssistHomePage extends StatefulWidget {
  @override
  _AssistHomePageState createState() => _AssistHomePageState();
}

class _AssistHomePageState extends State<AssistHomePage> {
  final FlutterTts flutterTts = FlutterTts();
  String _message = "Toque no botão para ouvir a mensagem.";

  Future _speak(String text) async {
    await flutterTts.setLanguage("pt-BR");
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Assistência Wear OS"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Assistência com Leitura de Texto",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              _message,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _message = "Olá, bem-vindo à assistência da empresa Doma. "
                      "Este dispositivo foi projetado para ajudar pessoas com necessidades especiais.";
                });
                _speak(_message);
              },
              child: Text("Ouvir Mensagem"),
            ),
          ],
        ),
      ),
    );
  }
}
