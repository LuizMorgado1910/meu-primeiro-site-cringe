import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class BannerDestaque extends StatelessWidget {
  final List<String> imagens = [
    'assets/imagem1.jpg',
    'assets/imagem2.jpg',
    'assets/imagem3.jpg'
  ];

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(height: 200.0, autoPlay: true),
      items: imagens.map((imagem) {
        return Builder(
          builder: (BuildContext context) {
            return GestureDetector(
              onTap: () {
                // Ação ao tocar na imagem (por exemplo, navegação para a página de destino)
                print("Imagem tocada!");
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.symmetric(horizontal: 5.0),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(imagem),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            );
          },
        );
      }).toList(),
    );
  }
}
