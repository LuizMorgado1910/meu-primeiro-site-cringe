import React from 'react';
import LivroLista from './LivroLista';

const App: React.FC = () => {
  return (
    <div>
      <LivroLista />
    </div>
  );
}
import React from 'react';
import { BrowserRouter, Route, Routes, Link } from 'react-router-dom';
import LivroDados from './LivroDados';
import LivroLista from './LivroLista'; 

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <Link className="navbar-brand" to="/">Lista de Livros</Link>
        <div className="navbar-nav">
          <Link className="nav-item nav-link" to="/">Home</Link>
          <Link className="nav-item nav-link" to="/dados">Dados</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<LivroLista />} />
        <Route path="/dados" element={<LivroDados />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;