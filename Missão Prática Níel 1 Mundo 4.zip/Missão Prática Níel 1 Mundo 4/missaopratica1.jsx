import React from 'react';

import { Text } from 'react-native';

 

const Cat = () => {

  const name = 'Maru';

  return <Text>Hello, I am {name}!</Text>;

  return (

    <View>

      <Text>Hello, I am...</Text>

      <TextInput

        style={{

          height: 40,

          borderColor: 'gray',

          borderWidth: 1,

        }}

        defaultValue="Name me!"

      />

    </View>

  );

};



export default Cat;



